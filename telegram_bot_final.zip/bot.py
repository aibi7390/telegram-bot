import telebot
import os

# دریافت توکن از محیط
TOKEN = os.getenv("TOKEN")
bot = telebot.TeleBot(TOKEN)

WELCOME_MESSAGE = """\
🇮🇷 سلام! به مرکز مشاوره خوش آمدید.
🇺🇸 Hello! Welcome to our consultation center.
🇩🇪 Hallo! Willkommen in unserem Beratungszentrum.
🇫🇷 Bonjour! Bienvenue dans notre centre de conseil.
"""

KEYWORDS = {
    "مهاجرت": "برای مشاوره مهاجرت، به کانال ما سر بزنید:\nhttps://t.me/aibicenter\nیا در واتساپ پیام دهید: +49123456789",
    "اقامت": "برای اطلاعات درباره اقامت، به ما در واتساپ پیام دهید: +49123456789",
    "ویزای": "مشاوره ویزا در کانال ما موجود است:\nhttps://t.me/aibicenter",
    "استارتاپ": "برای مشاوره استارتاپ، به ما در واتساپ پیام دهید یا کانال را ببینید:\nhttps://t.me/aibicenter",
    "دانشجویی": "مشاوره برای ویزای دانشجویی در واتساپ:\n+49123456789"
}

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, WELCOME_MESSAGE)

@bot.message_handler(func=lambda message: True)
def handle_message(message):
    text = message.text.lower()
    for keyword, response in KEYWORDS.items():
        if keyword in text:
            bot.reply_to(message, response)
            return
    bot.reply_to(message, "پاسخ مشخصی برای پیام شما ندارم. لطفاً از /start استفاده کنید یا یکی از کلیدواژه‌های رایج را بنویسید.")

print("ربات در حال اجراست...")
bot.infinity_polling()
